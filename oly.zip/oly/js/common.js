﻿// JavaScript Document
jQuery(".nav").slide({type:"menu",titCell:".nLi",targetCell:".sub",effect:"slideDown",delayTime:300,triggerTime:0,returnDefault:true});
jQuery(".sider").slide({titCell:"h3",targetCell:"ul",effect:"slideDown",trigger:"click",delayTime:300,triggerTime:150,defaultPlay:true,returnDefault:true});